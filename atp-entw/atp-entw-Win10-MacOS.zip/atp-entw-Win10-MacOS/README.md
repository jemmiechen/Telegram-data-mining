# ATP-ENTW Standalone Native Edition (Windows & macOS)

High-performance native C implementation of Siemens ATP Telegram & Diagnostic Event Analyzer.

## Key Advantages
- **100% Zero Dependency**: Pure native C binary executables. No Python installation, runtime, or external DLLs needed.
- **Embedded Web Asset**: The entire 900+ KB responsive web dashboard is compressed via Gzip and embedded directly into the binary.
- **Instant Launch**: Starts local HTTP server in milliseconds and automatically opens default browser.
- **Cross Platform**: Native binaries for Windows 10/11 x64, macOS Apple Silicon (M1/M2/M3/M4), and macOS Intel (x86_64).

## Usage Guide

### Windows 10 / 11
1. **Start Dashboard**: Double-click `啟動-ATP分析儀表板(Windows).bat` or `windows/atp_dashboard.exe`.
   - The web browser opens automatically to `http://localhost:8088/`.
2. **Convert DAT to LST**: Drag and drop `.DAT` files onto `轉換-DAT轉LST(Windows).bat`, or double-click it in a folder containing `.DAT` files.
   - Automatically outputs `.LST` files and `B-tel-list.txt` in a ZIP archive.

### macOS (Apple Silicon & Intel)
1. **Start Dashboard**: Double-click `ATP-ENTW.app` or run `啟動-ATP分析儀表板(MacOS).command`.
2. **Convert DAT to LST**: Double-click `轉換-DAT轉LST(MacOS).command` or execute `./macos/dat_to_lst <file.dat>`.

## Included Binaries
- `windows/atp_dashboard.exe`: Native Windows Web Server with embedded web application (~310 KB).
- `windows/dat_to_lst.exe`: Native Windows DAT-to-LST and track circuit parameter analyzer (~217 KB).
- `ATP-ENTW.app`: macOS Application bundle with Universal architecture support.
- `macos/atp_dashboard`: macOS Universal CLI dashboard launcher.
- `macos/dat_to_lst`: macOS Universal DAT converter and analyzer.
