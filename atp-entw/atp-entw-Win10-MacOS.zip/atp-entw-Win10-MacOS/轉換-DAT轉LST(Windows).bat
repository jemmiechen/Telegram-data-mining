@echo off
chcp 65001 >nul
title ATP DAT 批次轉換工具
echo =================================================================
echo 🚆 ATP DAT ➔ LST 診斷清單與軌道電路參數分析 (C 語言原生免安裝版)
echo =================================================================
echo.
if "%~1"=="" (
    echo [提示] 正在自動搜尋此目錄下的所有 .DAT 檔案進行轉換...
    "%~dp0windows\dat_to_lst.exe"
) else (
    echo [提示] 正在轉換傳入的檔案...
    "%~dp0windows\dat_to_lst.exe" %*
)
echo.
pause
