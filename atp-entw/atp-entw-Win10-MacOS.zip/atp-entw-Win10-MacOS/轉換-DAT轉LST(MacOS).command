#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "================================================================="
echo "🚆 ATP DAT ➔ LST 診斷清單與軌道電路參數分析 (C 語言原生免安裝版)"
echo "================================================================="
cd "$DIR"
if [ "$#" -eq 0 ]; then
    echo "[提示] 正在自動搜尋目錄下的 .DAT 檔案進行轉換..."
    "$DIR/macos/dat_to_lst"
else
    "$DIR/macos/dat_to_lst" "$@"
fi
echo ""
read -p "請按 Enter 鍵關閉視窗..." dummy
