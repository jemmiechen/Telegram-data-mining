#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -d "$DIR/ATP-ENTW.app" ]; then
    open "$DIR/ATP-ENTW.app"
else
    "$DIR/macos/atp_dashboard"
fi
