@echo off
title ATO gateway computer (TIC) - Guide Launcher
start "" "%~dp0guide\index.html"
