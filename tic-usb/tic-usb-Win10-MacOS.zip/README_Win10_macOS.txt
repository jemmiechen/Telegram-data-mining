ATO gateway computer (TIC) - Windows 10 / macOS Offline Guide Package
======================================================================

[繁體中文說明]
1. 請先將 tic-usb-Win10-MacOS.zip 完整解壓縮至任意資料夾。
2. Windows 10 使用者：雙擊「Open_Guide_Win10.bat」（或直接開啟 guide\index.html）。
3. macOS 使用者：雙擊「Open_Guide_macOS.command」（或直接以 Safari/Chrome 開啟 guide/index.html）。
   * 若 macOS 出現安全性提示，請對檔案按右鍵選擇「打開」即可。
4. 網頁首頁第 4 張卡片可直接下載或取得「tic-usb v1.01.zip」。

[English Instructions]
1. Extract tic-usb-Win10-MacOS.zip completely to a folder.
2. Windows 10: Double-click "Open_Guide_Win10.bat" (or open guide\index.html).
3. macOS: Double-click "Open_Guide_macOS.command" (or open guide/index.html in Safari/Chrome).
   * If macOS shows a Gatekeeper warning, right-click -> Open.
4. Use Card 4 on the home page to download "tic-usb v1.01.zip".
