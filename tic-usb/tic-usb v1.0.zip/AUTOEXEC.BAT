@echo off
path e:\windows;c:\dos;d:\tools;e:\backup;
SET TZ=0
SET TEMP=e:\TEMP
d:\tools\mops.exe

echo.
echo copy SICOSS files to flash disk
echo.
rem copy c:\backup\app\*.sib d:\app
rem copy c:\backup\app\gwr.exe d:\app
rem copy c:\backup\app\app.zip d:\app

echo.
echo copy all ATP files to memory stick
echo.
rem copy e:\backup\*.zip d:\log

echo.
echo copy all ATP files to flash disk
echo.
if exist e:\backup\fzg.zip goto ready
e:
rem mkdir backup

:ready
rem a:\transfer.exe
rem del c:\log\cab.zip
rem e:\backup\zip c:\log\cab e:\log\*.*
del c:\log\store.lgd
del c:\log\cab.txt
copy e:\cab.txt c:\log
copy e:\log\store.lgd c:\log

rem if exist e:\log\store.zip del e:\log\store.zip
rem c:\backup\zip -1 e:\log\store.zip e:\log\store.lgd
REM if exist c:\log\store.zip del c:\log\store.zip
REM if exist c:\log\cab.txt del c:\log\cab.txt
REM copy e:\cab.txt c:\log
REM copy e:\log\store.zip c:\log
c:
cd\log

