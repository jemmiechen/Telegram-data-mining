# Kontron MOPSlcdLX USB 開機與 Log 壓縮下載設定說明

本目錄包含用於 **Kontron MOPSlcdLX PC/104-Plus SBC**（AMD Geode LX + CS5536）之 USB 開機自動執行、Log 壓縮下載與多代備份設定檔及相關說明文件。

## 目錄檔案說明

| 檔案 / 目錄 | 說明 |
| :--- | :--- |
| `AUTOEXEC.BAT` | 單次手動下載基準版（保留直接複製 `store.lgd` 與註解掉的 `c:\backup\zip -1` 測試區段） |
| `AUTOEXEC.A01` | 實機驗證版 10 次迴圈設定（支援 `F:` RAMDISK 執行 `APP.BAT`、第 9 次 `zip -1` 壓縮、第 10 次 `store.zip` + `store01.zip`～`store05.zip` 備份） |
| `AUTOEXEC.A02` | 進階迭代備份版 10 次迴圈設定（以 `FOR` 兩階段掃描支援 `store00.zip`～`store99.zip`～`storeZ9.zip` 共 360 個備份檔） |
| `CONFIG.SYS` / `CONFIG.A01` | 統一採用 Windows 98 SE DOS 驅動（`HIMEM.SYS`、`EMM386.EXE NOEMS`、`RAMDRIVE.SYS 32767 /e`） |
| `USBA1/` | USB 開機碟目錄結構（`dos/` 已更新為純 Win98 SE 系統檔，原 FreeDOS 檔案移至 `FDOS/`） |
| `ssd/` | 板載 SSD 內容結構（`APP/`、`TOOLS/`、`DOS/`、`AUTOEXEC.BAT`、`CONFIG.SYS`） |
| `usb_boot_guide.odt` | LibreOffice 完整設定與版本注意事項說明文件 |
| `usb_boot_guide.pdf` | 由 LibreOffice 匯出之 PDF 說明文件 |

---

## 版本演進比較（`AUTOEXEC.BAT` / `AUTOEXEC.A01` / `AUTOEXEC.A02`）

| 項目 | `AUTOEXEC.BAT` | `AUTOEXEC.A01` | `AUTOEXEC.A02` |
| :--- | :--- | :--- | :--- |
| **執行模式** | 單次開機直接複製 | 10 次開機迴圈 | 10 次開機迴圈 |
| **環境變數** | `SET TZ=0`、`SET TEMP=e:\TEMP` | `SET TZ=0`、`SET TEMP=e:\TEMP` | `SET TZ=0`、`SET TEMP=e:\TEMP` |
| **第 1～8 次** | — | 解壓 `D:\APP\*.zip` 至 `F:\` 執行 `APP.BAT` | 解壓 `D:\APP\*.zip` 至 `F:\` 執行 `APP.BAT` |
| **第 9 次** | — | `c:\backup\zip -1` 壓縮後 `goto RUN_APP` | `c:\backup\zip -1` 壓縮後 `goto RUN_APP` |
| **第 10 次備份** | 直接複製 `store.lgd` | `if exist` 逐行檢查（最多 `store05.zip`，共 5+1 份） | `FOR` 兩階段掃描（`store00.zip`～`storeZ9.zip`，共 **360 份**） |
| **滿檔保護** | — | 覆寫 `store05.zip` | `:LOG_FULL` 警告並覆寫 `storeZ9.zip` |

---

## 磁碟機代號配置（USB 開機後）

| 代號 | 裝置 | 主要用途 |
| :---: | :--- | :--- |
| `C:` | USB 開機隨身碟 | 存放 Win98 SE 開機核心、`C:\DOS\`（純 Win98 SE 驅動）、`C:\BACKUP\ZIP.EXE` 與 `C:\LOG\` |
| `D:` | SSD 第一分割區 | 存放 `D:\APP\APP.ZIP`、`D:\TOOLS\UNZIP.EXE`、`D:\TOOLS\MOPS.EXE` |
| `E:` | SSD 第二分割區 | 存放原始紀錄檔 `E:\LOG\STORE.LGD`（約 28 MB）、`E:\CAB.TXT` 及暫存目錄 `E:\TEMP` |
| `F:` | RAMDISK（32 MB） | 由 `C:\DOS\RAMDRIVE.SYS 32767 /e` 建立，供解壓並執行 `APP.BAT`（`GWR.EXE`） |

---

## `AUTOEXEC.A02` 360 檔迭代備份原理

在純 MS-DOS `COMMAND.COM` 下，因單行指令長度上限為 127 字元，將群組掃描拆為兩行 `FOR` 反向掃描（總計 46 次檢查）即可定位下一個可用檔名：

```bat
set _GRP=
set _NUM=
for %%t in (Z Y X W V U T S R Q P O N M L K J I) do if not exist c:\log\store%%t9.zip set _GRP=%%t
for %%t in (H G F E D C B A 9 8 7 6 5 4 3 2 1 0) do if not exist c:\log\store%%t9.zip set _GRP=%%t
if "%_GRP%"=="" goto LOG_FULL
for %%u in (9 8 7 6 5 4 3 2 1 0) do if not exist c:\log\store%_GRP%%%u.zip set _NUM=%%u

copy e:\log\store.zip c:\log\store%_GRP%%_NUM%.zip
```

* `00`～`99`（100 檔）+ `A0`～`Z9`（260 檔）= **360 檔**，全數符合 MS-DOS 8.3 檔名規範。
* 完成後於 `:STEP11` 清除 `_GRP`、`_NUM` 變數與 `c:\log\step*.flg`，並 `goto RUN_APP` 繼續執行應用程式。

---

## FreeDOS 與 Windows 98 DOS 注意事項

* **實機已統一為純 Windows 98 SE DOS**：`USBA1\dos\` 已替換為完整 Win98 SE（1999/04/23）原生檔案（含 `HIMEM.SYS`、`EMM386.EXE`、`RAMDRIVE.SYS` 等），原 FreeDOS 工具目錄已移至 `USBA1\FDOS\`。
* **不可混用 SSD（`D:\DOS\`）的系統驅動**：SSD 為另一套舊版 MS-DOS，混用會造成 `Incorrect DOS version` 錯誤。
* **壓縮程式路徑**：`C:\DOS\` 改為純 Win98 SE 檔案後已無 FreeDOS 版 `ZIP.EXE`，請維持使用 `c:\backup\zip`。

---

## 上線步驟

1. 依需求選用 `AUTOEXEC.A01`（5 份備份）或 `AUTOEXEC.A02`（360 份備份）。
2. 將選用的檔案更名為 `AUTOEXEC.BAT`，`CONFIG.A01` 更名為 `CONFIG.SYS`，並同步覆蓋至 USB 開機磁區（`USBA1\`）根目錄。
